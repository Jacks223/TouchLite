package dev.prince.touchlite.mixin;

import dev.prince.touchlite.TouchLite;
import net.minecraft.client.Mouse;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Shadow private double x;
    @Shadow private double y;
    @Inject(method="onMouseButton", at=@At("HEAD"), cancellable=true)
    private void touchlite$onMouseButton(long window,int button,int action,int mods,CallbackInfo ci) {
        if(button!=GLFW.GLFW_MOUSE_BUTTON_LEFT) return;
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc==null||mc.getWindow()==null) return;
        double sx=x*mc.getWindow().getScaledWidth()/Math.max(1,mc.getWindow().getWidth());
        double sy=y*mc.getWindow().getScaledHeight()/Math.max(1,mc.getWindow().getHeight());
        if(TouchLite.handleMouseButton(action,sx,sy)) ci.cancel();
    }
}
