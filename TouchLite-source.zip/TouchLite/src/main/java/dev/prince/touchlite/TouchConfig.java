package dev.prince.touchlite;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Tiny human-readable JSON configuration; no external config library required. */
public final class TouchConfig {
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("touchlite.json");
    public boolean snap = true;
    public int grid = 8;
    public boolean showWhileEditing = true;
    public List<Control> controls = defaults();

    public static final class Control {
        public String id;
        public String label;
        public String action;
        /** Normalized top-left position, 0..1. */
        public float x, y;
        public float scale = 1.0f;
        /** 0.15..1.0 */
        public float opacity = 0.72f;
        /** Independent clickable region multiplier; may differ from visible button size. */
        public float hitboxWidth = 1.0f, hitboxHeight = 1.0f;
        public boolean enabled = true;
        public Control() {}
        public Control(String id, String label, String action, float x, float y) {
            this.id=id; this.label=label; this.action=action; this.x=x; this.y=y;
        }
        public Control copy() {
            Control c = new Control(id,label,action,x,y); c.scale=scale; c.opacity=opacity; c.hitboxWidth=hitboxWidth; c.hitboxHeight=hitboxHeight; c.enabled=enabled; return c;
        }
    }

    public static List<Control> defaults() {
        List<Control> c = new ArrayList<>();
        c.add(new Control("forward","▲","forward",.105f,.66f));
        c.add(new Control("back","▼","back",.105f,.83f));
        c.add(new Control("left","◀","left",.025f,.745f));
        c.add(new Control("right","▶","right",.185f,.745f));
        c.add(new Control("jump","JUMP","jump",.865f,.66f));
        c.add(new Control("sneak","SNEAK","sneak",.865f,.83f));
        c.add(new Control("sprint","RUN","sprint",.735f,.83f));
        c.add(new Control("attack","HIT","attack",.735f,.50f));
        c.add(new Control("use","USE","use",.865f,.50f));
        c.add(new Control("inventory","INV","inventory",.025f,.06f));
        return c;
    }

    public static TouchConfig load() {
        try (Reader r = Files.newBufferedReader(FILE)) {
            TouchConfig loaded = GSON.fromJson(r, TouchConfig.class);
            if (loaded != null && loaded.controls != null && !loaded.controls.isEmpty()) {
                if (loaded.grid < 2 || loaded.grid > 64) loaded.grid=8;
                for (Control c : loaded.controls) sanitize(c);
                return loaded;
            }
        } catch (Exception ignored) {}
        return new TouchConfig();
    }
    public void save() {
        try { Files.createDirectories(FILE.getParent()); try (Writer w=Files.newBufferedWriter(FILE)) { GSON.toJson(this,w); } }
        catch (Exception e) { TouchLite.LOGGER.error("Could not save TouchLite config", e); }
    }
    public Control get(String id) { for (Control c:controls) if (c.id.equals(id)) return c; return null; }
    public static void sanitize(Control c) {
        c.x=clamp(c.x,0,1); c.y=clamp(c.y,0,1); c.scale=clamp(c.scale,.55f,2.0f); c.opacity=clamp(c.opacity,.15f,1.0f); c.hitboxWidth=clamp(c.hitboxWidth,.5f,2.5f); c.hitboxHeight=clamp(c.hitboxHeight,.5f,2.5f);
    }
    public static float clamp(float v,float lo,float hi) { return Math.max(lo,Math.min(hi,v)); }
}
