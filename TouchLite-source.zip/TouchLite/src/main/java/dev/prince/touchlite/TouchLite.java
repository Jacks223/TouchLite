package dev.prince.touchlite;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TouchLite implements ClientModInitializer {
    public static final String MOD_ID = "touchlite";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static TouchConfig CONFIG;
    public static KeyBinding editorKey;
    private static String heldControl;

    @Override public void onInitializeClient() {
        CONFIG = TouchConfig.load();
        editorKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.touchlite.editor", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.touchlite"));
        HudRenderCallback.EVENT.register((draw, tickDelta) -> renderHud(draw));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (editorKey.wasPressed()) client.setScreen(new TouchEditorScreen());
        });
        LOGGER.info("TouchLite loaded: {} configurable controls", CONFIG.controls.size());
    }

    public static int buttonSize(TouchConfig.Control c) { return Math.round(48 * c.scale); }
    public static int controlX(TouchConfig.Control c, int screenW) { return Math.round(c.x * screenW); }
    public static int controlY(TouchConfig.Control c, int screenH) { return Math.round(c.y * screenH); }

    private static void renderHud(DrawContext draw) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || mc.currentScreen != null) return;
        int sw=mc.getWindow().getScaledWidth(), sh=mc.getWindow().getScaledHeight();
        for (TouchConfig.Control c : CONFIG.controls) {
            if (!c.enabled) continue;
            int x=controlX(c,sw), y=controlY(c,sh), size=buttonSize(c);
            int alpha=Math.round(c.opacity*190); int bg=(alpha<<24)|0x171D2A;
            draw.fill(x,y,x+size,y+size,bg);
            draw.fill(x,y,x+size,y+2,(Math.min(255,alpha+35)<<24)|0xB9D8FF);
            draw.fill(x,y+size-2,x+size,y+size,(Math.min(255,alpha+35)<<24)|0xB9D8FF);
            draw.fill(x,y,x+2,y+size,(Math.min(255,alpha+35)<<24)|0xB9D8FF);
            draw.fill(x+size-2,y,x+size,y+size,(Math.min(255,alpha+35)<<24)|0xB9D8FF);
            draw.drawCenteredTextWithShadow(mc.textRenderer, Text.literal(c.label), x+size/2, y+size/2-4, 0xFFFFFFFF);
        }
    }

    /** Called by the mouse mixin; Android launchers that map touch to mouse work automatically. */
    public static boolean handleMouseButton(int action, double x, double y) {
        MinecraftClient mc=MinecraftClient.getInstance();
        if (mc.currentScreen != null || mc.player == null) return false;
        if (action == GLFW.GLFW_RELEASE) {
            if (heldControl != null) { setAction(heldControl,false); heldControl=null; return true; }
            return false;
        }
        if (action != GLFW.GLFW_PRESS) return false;
        int sw=mc.getWindow().getScaledWidth(), sh=mc.getWindow().getScaledHeight();
        for (int i=CONFIG.controls.size()-1;i>=0;i--) {
            TouchConfig.Control c=CONFIG.controls.get(i); if (!c.enabled) continue;
            int size=buttonSize(c);
            int bx=controlX(c,sw)+size/2-Math.round(size*c.hitboxWidth/2f);
            int by=controlY(c,sh)+size/2-Math.round(size*c.hitboxHeight/2f);
            int bw=Math.round(size*c.hitboxWidth), bh=Math.round(size*c.hitboxHeight);
            if (x>=bx && x<=bx+bw && y>=by && y<=by+bh) {
                heldControl=c.id;
                setAction(c.action,true);
                if (c.action.equals("inventory")) { setAction(c.action,false); heldControl=null; }
                return true;
            }
        }
        return false;
    }
    public static void releaseAll() { if (heldControl!=null) setAction(heldControl,false); heldControl=null; }
    private static void setAction(String action, boolean down) {
        MinecraftClient mc=MinecraftClient.getInstance(); if (mc.options==null) return;
        KeyBinding key=switch(action) {
            case "forward" -> mc.options.forwardKey; case "back" -> mc.options.backKey;
            case "left" -> mc.options.leftKey; case "right" -> mc.options.rightKey;
            case "jump" -> mc.options.jumpKey; case "sneak" -> mc.options.sneakKey;
            case "sprint" -> mc.options.sprintKey; case "attack" -> mc.options.attackKey;
            case "use" -> mc.options.useKey; case "inventory" -> mc.options.inventoryKey;
            default -> null;
        };
        if (key!=null) key.setPressed(down);
    }
}
