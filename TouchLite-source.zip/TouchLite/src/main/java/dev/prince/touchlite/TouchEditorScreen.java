package dev.prince.touchlite;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** One-screen editor: tap/drag controls; use the right panel for common settings. */
public final class TouchEditorScreen extends Screen {
    private String selectedId = "jump";
    private String draggingId;
    private double dragDX, dragDY;
    private final List<List<TouchConfig.Control>> history = new ArrayList<>();
    private int historyIndex = -1;

    public TouchEditorScreen() { super(Text.literal("TouchLite Layout Editor")); pushHistory(); }
    private TouchConfig.Control selected() { return TouchLite.CONFIG.get(selectedId); }
    private int panelX() { return width - 166; }

    @Override public void render(DrawContext d, int mouseX, int mouseY, float delta) {
        renderBackground(d);
        d.fill(0,0,width,height,0x40000000);
        for (TouchConfig.Control c : TouchLite.CONFIG.controls) {
            int x=TouchLite.controlX(c,width), y=TouchLite.controlY(c,height), size=TouchLite.buttonSize(c);
            int bg=c.id.equals(selectedId)?0xC0448DFF:(c.enabled?0xAA171D2A:0x55171D2A);
            int hx=x+size/2-Math.round(size*c.hitboxWidth/2f), hy=y+size/2-Math.round(size*c.hitboxHeight/2f);
            int hw=Math.round(size*c.hitboxWidth), hh=Math.round(size*c.hitboxHeight);
            d.fill(hx,hy,hx+hw,hy+1,0xFF7FFFD4); d.fill(hx,hy+hh-1,hx+hw,hy+hh,0xFF7FFFD4);
            d.fill(hx,hy,hx+1,hy+hh,0xFF7FFFD4); d.fill(hx+hw-1,hy,hx+hw,hy+hh,0xFF7FFFD4);
            d.fill(x,y,x+size,y+size,bg);
            d.fill(x,y,x+size,y+2,0xFFB9D8FF); d.fill(x,y+size-2,x+size,y+size,0xFFB9D8FF);
            d.fill(x,y,x+2,y+size,0xFFB9D8FF); d.fill(x+size-2,y,x+size,y+size,0xFFB9D8FF);
            d.drawCenteredTextWithShadow(textRenderer,Text.literal(c.label),x+size/2,y+size/2-4,0xFFFFFFFF);
            if (!c.enabled) d.drawTextWithShadow(textRenderer,Text.literal("OFF"),x+2,y+2,0xFFFF7777);
        }
        int px=panelX();
        d.fill(px-5,0,width,height,0xE6121722);
        d.drawTextWithShadow(textRenderer,Text.literal("TouchLite"),px,8,0xFFFFFFFF);
        d.drawTextWithShadow(textRenderer,Text.literal("Drag any control"),px,22,0xFFB9D8FF);
        TouchConfig.Control c=selected();
        if(c!=null) {
            d.drawTextWithShadow(textRenderer,Text.literal("Selected: "+c.id),px,40,0xFFFFFFFF);
            d.drawTextWithShadow(textRenderer,Text.literal("X: "+Math.round(c.x*100)+"%  (tap ±)"),px,54,0xFFDDDDDD);
            d.drawTextWithShadow(textRenderer,Text.literal("Y: "+Math.round(c.y*100)+"%  (tap ±)"),px,66,0xFFDDDDDD);
            d.drawTextWithShadow(textRenderer,Text.literal("Size: "+Math.round(c.scale*100)+"%"),px,78,0xFFDDDDDD);
            d.drawTextWithShadow(textRenderer,Text.literal("Opacity: "+Math.round(c.opacity*100)+"%"),px,90,0xFFDDDDDD);
            d.drawTextWithShadow(textRenderer,Text.literal("Hitbox W/H: "+Math.round(c.hitboxWidth*100)+"/"+Math.round(c.hitboxHeight*100)+"%"),px,102,0xFF7FFFD4);
            drawButton(d,px,120,"Toggle enabled"); drawButton(d,px,140,"Size  − / +");
            drawButton(d,px,160,"Opacity − / +"); drawButton(d,px,180,"Hitbox width − / +");
            drawButton(d,px,200,"Hitbox height − / +"); drawButton(d,px,220,"Snap: "+(TouchLite.CONFIG.snap?"ON":"OFF"));
            drawButton(d,px,240,"Undo"); drawButton(d,px,260,"Redo");
            drawButton(d,px,280,"Preset: Bedrock"); drawButton(d,px,300,"Preset: Compact");
            drawButton(d,px,320,"Reset layout");
        }
        d.drawTextWithShadow(textRenderer,Text.literal("Tap a control to select"),8,height-30,0xFFFFFFFF);
        d.drawTextWithShadow(textRenderer,Text.literal("ESC: close  •  arrows: nudge  •  wheel: size"),8,height-18,0xFFDDDDDD);
        super.render(d,mouseX,mouseY,delta);
    }
    private void drawButton(DrawContext d,int x,int y,String label) {
        d.fill(x,y,x+126,y+18,0xFF303B4B); d.fill(x,y,x+126,y+1,0xFF657C9C);
        d.drawCenteredTextWithShadow(textRenderer,Text.literal(label),x+63,y+5,0xFFFFFFFF);
    }
    @Override public boolean mouseClicked(double mx,double my,int button) {
        if(button!=0) return super.mouseClicked(mx,my,button);
        int px=panelX();
        if(mx>=px-5) { handlePanel((int)my,mx); return true; }
        for(int i=TouchLite.CONFIG.controls.size()-1;i>=0;i--) {
            TouchConfig.Control c=TouchLite.CONFIG.controls.get(i); int x=TouchLite.controlX(c,width),y=TouchLite.controlY(c,height),s=TouchLite.buttonSize(c);
            if(mx>=x&&mx<=x+s&&my>=y&&my<=y+s) {
                pushHistory(); selectedId=c.id; draggingId=c.id; dragDX=mx-x; dragDY=my-y; return true;
            }
        }
        return true;
    }
    private void handlePanel(int y,double mx) {
        TouchConfig.Control c=selected(); if(c==null)return;
        if(y>=54&&y<66){pushHistory();c.x=TouchConfig.clamp(c.x+(mx<panelX()+83?-.01f:.01f),0,1);TouchLite.CONFIG.save();return;}
        if(y>=66&&y<78){pushHistory();c.y=TouchConfig.clamp(c.y+(mx<panelX()+83?-.01f:.01f),0,1);TouchLite.CONFIG.save();return;}
        if(y>=120&&y<140){pushHistory();c.enabled=!c.enabled;}
        else if(y>=140&&y<160){pushHistory();c.scale=TouchConfig.clamp(c.scale+(c.scale<1.01f?.15f:-.15f),.55f,2f);}
        else if(y>=160&&y<180){pushHistory();c.opacity=TouchConfig.clamp(c.opacity+(c.opacity<.8f?.15f:-.15f),.15f,1f);}
        else if(y>=180&&y<200){pushHistory();c.hitboxWidth=TouchConfig.clamp(c.hitboxWidth+(c.hitboxWidth<1.1f?.25f:-.25f),.5f,2.5f);}
        else if(y>=200&&y<220){pushHistory();c.hitboxHeight=TouchConfig.clamp(c.hitboxHeight+(c.hitboxHeight<1.1f?.25f:-.25f),.5f,2.5f);}
        else if(y>=220&&y<240){TouchLite.CONFIG.snap=!TouchLite.CONFIG.snap;}
        else if(y>=240&&y<260){undo();return;}
        else if(y>=260&&y<280){redo();return;}
        else if(y>=280&&y<300){pushHistory();applyBedrock();}
        else if(y>=300&&y<320){pushHistory();applyCompact();}
        else if(y>=320&&y<340){pushHistory();TouchLite.CONFIG.controls=TouchConfig.defaults();selectedId="jump";}
        TouchConfig.sanitize(c); TouchLite.CONFIG.save();
    }
    @Override public boolean mouseDragged(double mx,double my,int button,double dx,double dy) {
        if(draggingId!=null){TouchConfig.Control c=TouchLite.CONFIG.get(draggingId);if(c!=null){
            float nx=(float)((mx-dragDX)/Math.max(1,width)); float ny=(float)((my-dragDY)/Math.max(1,height));
            if(TouchLite.CONFIG.snap){float gx=TouchLite.CONFIG.grid/(float)Math.max(1,width);float gy=TouchLite.CONFIG.grid/(float)Math.max(1,height);nx=Math.round(nx/gx)*gx;ny=Math.round(ny/gy)*gy;}
            c.x=TouchConfig.clamp(nx,0,1);c.y=TouchConfig.clamp(ny,0,1);
        }return true;} return super.mouseDragged(mx,my,button,dx,dy);
    }
    @Override public boolean mouseReleased(double mx,double my,int button){if(draggingId!=null){draggingId=null;TouchLite.CONFIG.save();return true;}return super.mouseReleased(mx,my,button);}
    @Override public boolean mouseScrolled(double mx,double my,double amount){TouchConfig.Control c=selected();if(c!=null){pushHistory();c.scale=TouchConfig.clamp(c.scale+(amount>0?.05f:-.05f),.55f,2f);TouchLite.CONFIG.save();return true;}return super.mouseScrolled(mx,my,amount);}
    @Override public boolean keyPressed(int key,int scan,int modifiers){
        if(key==GLFW.GLFW_KEY_ESCAPE){close();return true;}
        TouchConfig.Control c=selected(); if(c!=null){float step=TouchLite.CONFIG.snap?TouchLite.CONFIG.grid/(float)Math.max(1,width):.005f;
            if(key==GLFW.GLFW_KEY_LEFT||key==GLFW.GLFW_KEY_RIGHT||key==GLFW.GLFW_KEY_UP||key==GLFW.GLFW_KEY_DOWN){pushHistory();if(key==GLFW.GLFW_KEY_LEFT)c.x-=step;if(key==GLFW.GLFW_KEY_RIGHT)c.x+=step;if(key==GLFW.GLFW_KEY_UP)c.y-=step;if(key==GLFW.GLFW_KEY_DOWN)c.y+=step;TouchConfig.sanitize(c);TouchLite.CONFIG.save();return true;}}
        return super.keyPressed(key,scan,modifiers);
    }
    @Override public void close(){TouchLite.CONFIG.save();super.close();}
    private void pushHistory(){while(history.size()>historyIndex+1)history.remove(history.size()-1);history.add(copyAll());historyIndex=history.size()-1;if(history.size()>40){history.remove(0);historyIndex--;}}
    private List<TouchConfig.Control> copyAll(){List<TouchConfig.Control> out=new ArrayList<>();for(TouchConfig.Control c:TouchLite.CONFIG.controls)out.add(c.copy());return out;}
    private void restore(List<TouchConfig.Control> list){TouchLite.CONFIG.controls=new ArrayList<>();for(TouchConfig.Control c:list)TouchLite.CONFIG.controls.add(c.copy());if(TouchLite.CONFIG.get(selectedId)==null&&!TouchLite.CONFIG.controls.isEmpty())selectedId=TouchLite.CONFIG.controls.get(0).id;TouchLite.CONFIG.save();}
    private void undo(){if(historyIndex>0){historyIndex--;restore(history.get(historyIndex));}}
    private void redo(){if(historyIndex<history.size()-1){historyIndex++;restore(history.get(historyIndex));}}
    private void applyBedrock(){String[] ids={"forward","back","left","right","jump","sneak","sprint","attack","use","inventory"};float[][] p={{.10f,.65f},{.10f,.82f},{.02f,.735f},{.18f,.735f},{.88f,.68f},{.88f,.84f},{.74f,.84f},{.75f,.49f},{.88f,.49f},{.02f,.06f}};for(int i=0;i<ids.length;i++){TouchConfig.Control c=TouchLite.CONFIG.get(ids[i]);if(c!=null){c.x=p[i][0];c.y=p[i][1];c.scale=1.15f;c.opacity=.8f;c.enabled=true;}}}
    private void applyCompact(){for(TouchConfig.Control c:TouchLite.CONFIG.controls){c.scale=.75f;c.opacity=.55f;} }
}
