# Build TouchLite without a PC (using GitHub Actions)

This project includes `.github/workflows/build.yml` for cloud builds.

1. On your phone, sign in to GitHub and create a **public** repository named `TouchLite`.
2. Extract this project ZIP on your phone using your file manager or an archive app.
3. Upload the **contents** of the extracted `TouchLite` folder to the repository, preserving folders (especially `.github/workflows/build.yml`, `src`, `gradle`, and the Gradle files). Do not upload only the ZIP.
4. Open the repository's **Actions** tab and select **Build TouchLite**. Tap **Run workflow** if it has not started automatically.
5. When the run finishes successfully, open the run and download the artifact named `TouchLite-1.20.1-Fabric`.
6. Extract the artifact and copy the normal mod JAR (not the `-sources.jar`) into Zalith Launcher's Minecraft 1.20.1 Fabric `mods` folder. Fabric API must also be installed.

The first cloud build downloads Gradle, Minecraft, mappings, and Fabric dependencies, so it needs internet access. The mod has not yet been verified in-game; a successful build is not a guarantee that all touch input works with every launcher.
