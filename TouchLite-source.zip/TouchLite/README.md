# TouchLite — simple customizable touch HUD

A small, standalone Fabric client mod for **Minecraft Java 1.20.1** (Java 17), designed for Android launchers such as Zalith that translate touchscreen taps into mouse events. This is an independent, simplified implementation, not a fork of TouchController.

## Current features
- Ten configurable overlay actions: forward/back/left/right, jump, sneak, sprint, attack, use, inventory.
- In-game layout editor (default **G**) with direct drag-and-drop positioning.
- Per-control enabled state, size/scale and opacity settings.
- Percentage-based positions so layouts adapt to screen resolution.
- Optional grid snapping; arrow-key nudging; mouse wheel size adjustment.
- Undo/redo during an editor session; Bedrock-ish and compact presets; reset layout.
- Human-readable JSON config at `.minecraft/config/touchlite.json`.
- No external configuration library and no background network activity.

## Build
Requires JDK 17 and internet access the first time Gradle downloads Minecraft/Fabric dependencies.

```sh
./gradlew build
```

The output JAR should be in `build/libs/`. Put it in the Fabric instance's `mods` folder alongside Fabric API.

## Controls
- Press **G** in-game to open the editor.
- Tap a control to select it; drag it to reposition.
- Right-side panel toggles the selected control, changes size/opacity, toggles snapping, undo/redo, loads presets, or resets the layout.
- Arrow keys nudge the selected control; scroll to resize.
- Press Escape to close and save.

## Important current limitations
- The first version uses tap/hold input through Minecraft's mouse event path. Touch behavior depends on how the Android launcher maps touch events to mouse events.
- Inventory is a tap action; movement/action buttons are hold actions.
- This is source code, not a prebuilt, tested JAR. It has not yet been verified in a running Minecraft client. Verify build and in-game input behavior before relying on it.
- It intentionally starts with a small feature set. Joystick input, independent hitbox shapes, multi-profile export/import, per-world profiles, and a polished touch-first settings panel are not implemented yet.

## License
MIT for this standalone implementation. Fabric, Minecraft, and their dependencies retain their own licenses.
